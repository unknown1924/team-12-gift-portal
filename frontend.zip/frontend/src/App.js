import './App.css'
import AboutUs from './components/AboutUs/AboutUs'
import Footer from './components/Footer/Footer'
import Navbar from './components/Navbar/Navbar'
import Product from './components/Products/Products'
import User from './components/User/User'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import Home from './components/Home1/Home'
import Admin from './components/Admin/Admin'
import AdminNavbar from './components/Admin/AdminNavbar'
import AdminUser from './components/Admin/pages/AdminUser'
import AdminOrder from './components/Admin/pages/AdminOrder'
import AdminComplaint from './components/Admin/pages/AdminComplaint'
import Hom from './components/Admin/pages/Hom'

function App() {
  return (
    <div className='App'>
      <Router>
        <AdminNavbar />

        <Switch>
          <Route path='/' exact>
            <Home />
          </Route>
          <Route path='/AdminComplaint' exact>
            <AdminComplaint />
          </Route>
          <Route path='/AdminOrder' exact>
            <AdminOrder />
          </Route>
          <Route path='/AdminUser' exact>
            <AdminUser />
          </Route>
          <Route path='/AdminComplaint' exact>
            <AdminComplaint />
          </Route>
          <Route path='/pages/Hom' exact>
            <Hom />
          </Route>
        </Switch>
      </Router>
    </div>
  )
}

export default App
