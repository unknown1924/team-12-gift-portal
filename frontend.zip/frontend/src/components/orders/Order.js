import React from 'react';

function Order(){
    return (
        <>
            <div className='container'>
                <div className='row'>
                    
                </div>
            </div>
        </>
    )
}

export default Order;