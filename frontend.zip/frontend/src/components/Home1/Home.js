import React from 'react'

function Home() {
  return (
    <div>
      <div>
        <h1>Home</h1>
      </div>
    </div>
  )
}

export default Home
