import React from "react";
import { Button } from "react-bootstrap";

const Admin = () => {
  return (
    <>
      <div className="container">
        <div className="row">
          <table class="table">
            <thead>
              <tr>
                <th>User</th>
                <th>Email</th>
                <th></th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>John</td>
                <td>Doe</td>
                <td>Edit</td>
                <td>Delete</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
};

export default Admin;
