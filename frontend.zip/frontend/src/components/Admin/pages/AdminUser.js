import React from 'react';

function AdminUser() {
    return (
        <div className='AdminUser'>
            <h1>AdminUser</h1>
        </div>
    )
}

export default AdminUser;