import React from 'react';

function AdminComplaint() {
    return (
        <div className='AdminComplaint'>
            <h1>AdminComplaint</h1>
        </div>
    )
}

export default AdminComplaint;