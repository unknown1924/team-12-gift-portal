import React from 'react'

function Hom() {
  return (
    <div className='home'>
      <h1>AdminHome</h1>
    </div>
  )
}

export default Hom
