import React from 'react';

function AdminOrder() {
    return (
        <div className='AdminOrder'>
            <h1>AdminOrder</h1>
        </div>
    )
}

export default AdminOrder;